import os
import glob
import re
import logging
from typing import Iterable, Optional, List, Tuple, Set

import psycopg2
from sentence_transformers import SentenceTransformer

log = logging.getLogger("question_generator")

# ----------------------------
# Настройки извлечения
# ----------------------------

# Слова, которые не должны начинать/составлять термин
FORBIDDEN_TERMS = {
    "если", "поскольку", "так как", "имеем", "пусть", "тогда", "далее",
    "следовательно", "от противного", "действительно", "заметим", "рассмотрим",
    "вход", "выход", "алгоритм", "при этом", "для", "который", "также",
    "выдвигая", "построение", "создание", "функций", "дерево", "граф",
    "этот", "эта", "это", "эти", "такой", "такая", "такое", "такие",
    "весь", "вся", "всё", "все", "один", "одна", "одно", "одни",
    "адельсон", "вельский", "ландис", "метод", "уровень", "добавляемое",
}

# Слова, с которых не должно начинаться определение
DEFINITION_STARTS_BLACKLIST = {
    "кратчайшее", "значит", "поскольку", "если", "так", "тогда", "далее",
    "следовательно", "например"
}

# Разделение текста на более-менее самостоятельные куски
UNIT_SPLIT_RE = re.compile(r"(?<=[.!?])\s+|\n+")

# Один "слово-токен" термина
WORD = r"(?:[А-ЯЁA-Z][А-ЯЁа-яёA-Z0-9\-]*|[а-яё][а-яёA-Z0-9\-]*)"
TERM = rf"{WORD}(?:\s+{WORD}){{0,4}}"

# Минимум/максимум длины определения
MIN_DEF_CHARS = 8
MAX_DEF_CHARS = 500
MIN_DEF_WORDS = 2
MAX_TERM_WORDS = 5

# Более широкий набор шаблонов
PATTERNS = [
    # X называется Y
    re.compile(
        rf"(?<!\w)(?P<term>{TERM})\s+"
        rf"(?:называется|именуется|обозначается|считается|является|представляет\s+собой)\s+"
        rf"(?P<definition>[^\n\r.!?;:]{{{MIN_DEF_CHARS}, {MAX_DEF_CHARS}}}[.!?])",
        re.IGNORECASE | re.MULTILINE | re.VERBOSE,
    ),
    # X — это Y / X - это Y / X: это Y
    re.compile(
        rf"(?<!\w)(?P<term>{TERM})\s*[-–—:]\s*(?:это\s+)?"
        rf"(?P<definition>[^\n\r.!?;:]{{{MIN_DEF_CHARS}, {MAX_DEF_CHARS}}}[.!?])",
        re.IGNORECASE | re.MULTILINE | re.VERBOSE,
    ),
    # Под X понимается Y
    re.compile(
        rf"(?<!\w)(?:Под\s+)?(?P<term>{TERM})\s+"
        rf"(?:понимается|понимают)\s+"
        rf"(?P<definition>[^\n\r.!?;:]{{{MIN_DEF_CHARS}, {MAX_DEF_CHARS}}}[.!?])",
        re.IGNORECASE | re.MULTILINE | re.VERBOSE,
    ),
    # X называют Y / X именуют Y / X обозначают Y
    re.compile(
        rf"(?<!\w)(?P<term>{TERM})\s+"
        rf"(?:называют|именуют|обозначают)\s+"
        rf"(?P<definition>[^\n\r.!?;:]{{{MIN_DEF_CHARS}, {MAX_DEF_CHARS}}}[.!?])",
        re.IGNORECASE | re.MULTILINE | re.VERBOSE,
    ),
    # Термин: определение
    re.compile(
        rf"(?<!\w)(?P<term>{TERM})\s*[:\-–—]\s*"
        rf"(?P<definition>[^\n\r.!?;:]{{{MIN_DEF_CHARS}, {MAX_DEF_CHARS}}}[.!?])",
        re.IGNORECASE | re.MULTILINE | re.VERBOSE,
    ),
]

QUESTION_TEMPLATES = (
    "Что такое {term}?",
    "Что означает {term}?",
    "Как определяется {term}?",
)

# ----------------------------
# Вспомогательные функции
# ----------------------------

def normalize_spaces(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()

def split_units(text: str) -> List[str]:
    # Сначала режем на абзацы/предложения, потом фильтруем пустые
    units = [normalize_spaces(x) for x in UNIT_SPLIT_RE.split(text)]
    return [u for u in units if u]

def is_formula_like(text: str) -> bool:
    # Не рубим определения просто из-за единичной формулы,
    # но если символов слишком много — скорее всего это не определение.
    symbols = re.findall(r"[=+\-*/^<>≈≠≤≥∑∫√∈∉⊂⊆⊃⊇→←↔|•·]", text)
    letters = re.findall(r"[A-Za-zА-Яа-яЁё]", text)
    if not letters:
        return True
    return len(symbols) >= 6 and (len(symbols) / max(len(text), 1)) > 0.10

def is_forbidden_term(term: str) -> bool:
    t = normalize_spaces(term.lower())
    if not t:
        return True

    # Проверяем по словам, а не startswith — это сильно снижает ложные срабатывания
    tokens = t.split()
    if not tokens:
        return True

    if len(tokens) > MAX_TERM_WORDS:
        return True

    if any(tok in FORBIDDEN_TERMS for tok in tokens):
        return True

    # Запрещённые фразы
    for bad in FORBIDDEN_TERMS:
        if " " in bad and re.search(rf"\b{re.escape(bad)}\b", t):
            return True

    # Термин должен содержать хотя бы одну букву
    if not re.search(r"[А-ЯЁа-яёA-Za-z]", t):
        return True

    return False

def clean_term(term: str) -> str:
    term = normalize_spaces(term)
    term = re.sub(r"^\d+(?:\.\d+)*[\.\)]?\s*", "", term)
    term = term.strip('"\''"«»„“”")
    term = re.sub(r"[;:,.!?]+$", "", term).strip()
    return normalize_spaces(term)

def clean_definition(definition: str) -> Optional[str]:
    definition = normalize_spaces(definition)
    definition = re.sub(r"^\d+(?:\.\d+)*[\.\)]?\s*", "", definition)
    definition = re.sub(r"^[-–—:;]\s*", "", definition)
    definition = re.sub(r"^(?:это|является)\s+", "", definition, flags=re.IGNORECASE)
    definition = normalize_spaces(definition)

    if not definition:
        return None

    first_word = definition.split()[0].lower()
    if first_word in DEFINITION_STARTS_BLACKLIST:
        return None

    if len(definition) < MIN_DEF_CHARS or len(definition) > MAX_DEF_CHARS:
        return None

    if len(definition.split()) < MIN_DEF_WORDS:
        return None

    if is_formula_like(definition):
        return None

    # Делаем первую букву заглавной, если это обычный текст
    if definition and definition[0].islower():
        definition = definition[0].upper() + definition[1:]

    return definition

def generate_question_variants(term: str) -> List[str]:
    term = normalize_spaces(term)
    if not term:
        return []

    if term.isupper():
        base = term
    else:
        base = term[0].upper() + term[1:]

    questions = [tpl.format(term=base) for tpl in QUESTION_TEMPLATES]

    # Убираем дубликаты, если они случайно появились
    uniq = []
    seen = set()
    for q in questions:
        if q not in seen:
            seen.add(q)
            uniq.append(q)
    return uniq

def question_exists(conn) -> bool:
    cur = conn.cursor()
    cur.execute("SELECT 1 FROM questions LIMIT 1")
    exists = cur.fetchone() is not None
    cur.close()
    return exists

def clear_questions(conn):
    cur = conn.cursor()
    cur.execute("TRUNCATE TABLE questions")
    conn.commit()
    cur.close()

# ----------------------------
# Извлечение определений
# ----------------------------
def extract_definitions(text: str) -> List[Tuple[str, str]]:
    """
    Ищет определения по всему тексту.
    Возвращает [(term, definition)]
    """

    text = normalize_spaces(text)

    candidates = []
    seen = set()

    patterns = [
        # X называется Y
        re.compile(
            r'([А-ЯЁA-Z][А-ЯЁа-яёA-Za-z0-9\- ]{1,60}?)\s+'
            r'(?:называется|называют|именуется|является|считается)\s+'
            r'(.{10,400}?[.!?])',
            re.IGNORECASE
        ),

        # X — это Y
        re.compile(
            r'([А-ЯЁA-Z][А-ЯЁа-яёA-Za-z0-9\- ]{1,60}?)\s*[-—–:]\s*'
            r'(?:это\s+)?'
            r'(.{10,400}?[.!?])',
            re.IGNORECASE
        ),

        # Под X понимается Y
        re.compile(
            r'Под\s+([А-ЯЁA-Z][А-ЯЁа-яёA-Za-z0-9\- ]{1,60}?)\s+'
            r'понимается\s+'
            r'(.{10,400}?[.!?])',
            re.IGNORECASE
        ),

        # X представляет собой Y
        re.compile(
            r'([А-ЯЁA-Z][А-ЯЁа-яёA-Za-z0-9\- ]{1,60}?)\s+'
            r'представляет\s+собой\s+'
            r'(.{10,400}?[.!?])',
            re.IGNORECASE
        ),
    ]

    for pattern in patterns:
        for match in pattern.finditer(text):

            term = clean_term(match.group(1))
            definition = clean_definition(match.group(2))

            if not term or not definition:
                continue

            if is_forbidden_term(term):
                continue

            # мусор
            if len(term.split()) > 5:
                continue

            if len(definition) < 15:
                continue

            key = (term.lower(), definition.lower())

            if key in seen:
                continue

            seen.add(key)

            candidates.append((term, definition))

    return candidates

# ----------------------------
# Основная функция
# ----------------------------

def generate_and_store_questions(txt_path: str, model: SentenceTransformer, db_url: str):
    log.info("Начинаем генерацию вопросов")

    txt_files = sorted(glob.glob(os.path.join(txt_path, "*.txt")))
    if not txt_files:
        log.warning("Нет .txt файлов для генерации вопросов")
        return

    conn = psycopg2.connect(db_url)

    try:
        all_defs: List[Tuple[str, str]] = []
        global_seen: Set[Tuple[str, str]] = set()

        for file in txt_files:
            with open(file, "r", encoding="utf-8") as f:
                text = f.read()

            defs = extract_definitions(text)
            log.info("%s: найдено определений %d", file, len(defs))

            for term, definition in defs:
                key = (term.lower(), definition.lower())
                if key not in global_seen:
                    global_seen.add(key)
                    all_defs.append((term, definition))

        log.info("Всего уникальных определений: %d", len(all_defs))

        if not all_defs:
            log.warning("Не найдено ни одного определения")
            return

        # По одному определению делаем несколько вариантов вопроса
        rows = []
        used_questions: Set[str] = set()

        for term, answer in all_defs:
            question_variants = generate_question_variants(term)

            # Эмбеддинг считаем по answer (как у тебя было),
            # но делаем это только один раз на пару term/answer
            emb = model.encode(
                [f"passage: {answer}"],
                normalize_embeddings=True,
                show_progress_bar=False,
            )[0].tolist()

            for q_text in question_variants:
                if q_text in used_questions:
                    continue
                used_questions.add(q_text)
                rows.append((q_text, answer, emb))

        log.info("Сформировано вопросов к вставке: %d", len(rows))

        cur = conn.cursor()
        inserted = 0

        # Вставка по одному — надёжнее, чем пытаться упереться в адаптацию vector/list
        for q_text, a_text, emb in rows:
            try:
                cur.execute(
                    "INSERT INTO questions (question_text, answer_text, embedding) VALUES (%s, %s, %s)",
                    (q_text, a_text, emb),
                )
                inserted += 1
            except Exception as e:
                log.exception("Не удалось вставить вопрос: %s", q_text)
                conn.rollback()
            else:
                # Коммитим пачками, чтобы не держать всё в одной транзакции
                if inserted % 200 == 0:
                    conn.commit()

        conn.commit()
        cur.close()

        log.info("Сохранено %d вопросов", inserted)

    finally:
        conn.close()

























# 
# 
# 
# 
# 
# import re
# import os
# import glob
# import logging
# import psycopg2
# from sentence_transformers import SentenceTransformer
# 
# log = logging.getLogger("question_generator")
# 
# # ================= ПАТТЕРНЫ (расширенные) =================
# PATTERNS = [
#     # X называется Y
#     re.compile(
#         r'(?<!\w)([А-ЯЁ][А-ЯЁа-яё]*(?:\s+[А-ЯЁа-яё]+){0,4})\s+называется\s+(.{10,400}?)[.!?;](?:\s|$)',
#         re.MULTILINE | re.DOTALL
#     ),
#     # X — Y или X – Y (тире)
#     re.compile(
#         r'(?<!\w)([А-ЯЁ][А-ЯЁа-яё]*(?:\s+[А-ЯЁа-яё]+){0,4})\s+[-–—]\s+([^.!?;]{10,400})[.!?;](?:\s|$)',
#         re.MULTILINE | re.DOTALL
#     ),
#     # X – это Y
#     re.compile(
#         r'(?<!\w)([А-ЯЁ][А-ЯЁа-яё]*(?:\s+[А-ЯЁа-яё]+){0,4})\s+[-–—]?\s*это\s+(.{10,400}?)[.!?;](?:\s|$)',
#         re.MULTILINE | re.DOTALL
#     ),
#     # Под X понимается Y
#     re.compile(
#         r'Под\s+([А-ЯЁ][А-ЯЁа-яё]*(?:\s+[А-ЯЁа-яё]+){0,4})\s+понимается\s+(.{10,400}?)[.!?;](?:\s|$)',
#         re.MULTILINE | re.DOTALL
#     ),
#     # X является Y
#     re.compile(
#         r'(?<!\w)([А-ЯЁ][А-ЯЁа-яё]*(?:\s+[А-ЯЁа-яё]+){0,4})\s+является\s+(.{10,400}?)[.!?;](?:\s|$)',
#         re.MULTILINE | re.DOTALL
#     ),
# ]
# 
# FORBIDDEN_TERMS = {
#     'если', 'поскольку', 'так как', 'имеем', 'пусть', 'тогда', 'далее',
#     'следовательно', 'от противного', 'действительно', 'заметим', 'рассмотрим',
#     'вход', 'выход', 'при этом', 'который', 'также',
#     'этот', 'эта', 'это', 'эти', 'такой', 'такая', 'такое', 'такие',
#     'весь', 'вся', 'всё', 'все', 'один', 'одна', 'одно', 'одни',
#     'метод', 'уровень', 'добавляемое', 'алгоритм', 'функций', 'дерево', 'граф',
# }
# 
# DEFINITION_STARTS_BLACKLIST = ('кратчайшее', 'значит', 'поскольку', 'если')
# 
# def clean_term(term: str) -> str:
#     term = term.strip()
#     term = re.sub(r'^\d+(\.\d+)*[\.\)]?\s*', '', term)
#     term = term.strip('"\'«»')
#     term = re.sub(r'[;:,.!?]$', '', term)
#     words = term.split()
#     if len(words) > 5:
#         term = ' '.join(words[:5])
#     return term
# 
# def clean_definition(definition: str):
#     definition = definition.strip()
#     definition = re.sub(r'^\d+(\.\d+)*[\.\)]?\s*', '', definition)
#     definition = re.sub(r'\s+', ' ', definition)
#     definition = re.sub(r'^[-–—:;]\s*', '', definition)
#     if not definition:
#         return None
#     first_word = definition.split()[0].lower() if definition else ''
#     if first_word in DEFINITION_STARTS_BLACKLIST:
#         return None
#     if definition[0].islower():
#         definition = definition[0].upper() + definition[1:]
#     definition = definition.rstrip(';')
#     return definition
# 
# def extract_definitions(text: str):
#     definitions = []
#     raw_matches = 0
#     for pattern in PATTERNS:
#         for match in pattern.finditer(text):
#             raw_matches += 1
#             term = match.group(1).strip()
#             definition = match.group(2).strip()
#             term = clean_term(term)
#             definition = clean_definition(definition)
#             if definition is None:
#                 continue
#             if len(term) < 3 or len(term) > 40:
#                 continue
#             if term.lower() in FORBIDDEN_TERMS:
#                 continue
#             if not re.search(r'[А-ЯЁа-яё]', term):
#                 continue
#             if len(definition) < 15 or len(definition) > 450:
#                 continue
#             definitions.append((term, definition))
#     log.info(f"Сырых совпадений: {raw_matches}, после фильтрации: {len(definitions)}")
#     seen = set()
#     unique = []
#     for term, defn in definitions:
#         key = term.lower()
#         if key not in seen:
#             seen.add(key)
#             unique.append((term, defn))
#     return unique
# 
# def generate_question(term: str) -> str:
#     if term.isupper():
#         return f"Что такое {term}?"
#     else:
#         return f"Что такое {term.lower()}?"
# 
# def clear_questions(conn):
#     cur = conn.cursor()
#     cur.execute("TRUNCATE TABLE questions")
#     conn.commit()
#     cur.close()
# 
# def question_exists(conn) -> bool:
#     cur = conn.cursor()
#     cur.execute("SELECT count(*) FROM questions")
#     count = cur.fetchone()[0]
#     cur.close()
#     return count > 0
# 
# def generate_and_store_questions(txt_path: str, model, db_url: str):
#     log.info("Начинаем генерацию вопросов")
#     conn = psycopg2.connect(db_url)
#     txt_files = glob.glob(os.path.join(txt_path, "*.txt"))
#     if not txt_files:
#         log.warning("Нет .txt файлов для генерации вопросов")
#         conn.close()
#         return
# 
#     all_definitions = []
#     for file in txt_files:
#         with open(file, "r", encoding="utf-8") as f:
#             text = f.read()
#         defs = extract_definitions(text)
#         all_definitions.extend(defs)
#         log.info(f"{file}: найдено определений {len(defs)}")
# 
#     log.info(f"Всего уникальных определений: {len(all_definitions)}")
# 
#     if not all_definitions:
#         log.warning("Не найдено ни одного определения")
#         conn.close()
#         return
# 
#     questions_data = []
#     for term, answer in all_definitions:
#         question_text = generate_question(term)
#         emb = model.encode([f"passage: {answer}"], normalize_embeddings=True)[0].tolist()
#         questions_data.append((question_text, answer, emb))
# 
#     cur = conn.cursor()
#     for q_text, a_text, emb in questions_data:
#         cur.execute(
#             "INSERT INTO questions (question_text, answer_text, embedding) VALUES (%s, %s, %s)",
#             (q_text, a_text, emb)
#         )
#     conn.commit()
#     cur.close()
#     conn.close()
#     log.info(f"Сохранено {len(questions_data)} вопросов")
